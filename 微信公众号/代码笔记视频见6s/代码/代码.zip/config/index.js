//配置对象模块
module.exports = {
  token: 'atguiguHTML0524',
  appID: 'wxc8e92f7ab70fbca0',
  appsecret: 'b4054e90b75787c78e0af50bf7fc3e87',
  url: 'http://4ef314c8.ngrok.io'
}